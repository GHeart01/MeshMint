// src/generators/galaxyData.ts
//
// ENGINE-NEUTRAL. No three / no babylon imports. Pure math in, typed arrays out.
// This is the part that never changes if you swap renderers — only the thin
// adapter that consumes { positions, colors } differs per engine.
//
// Ported from your original Galaxy.js: same spiral-arm + halo distribution and
// temperature-by-radius coloring, with THREE.Color replaced by a standalone
// hslToRgb helper so this file has no engine dependency.

export interface GalaxyParams {
  COUNT: number;       // number of points
  ARM_COUNT: number;   // spiral arms
  SPREAD: number;      // scatter of stars off the arms
  RADIUS: number;      // overall disk radius
  TILT: number;        // vertical shear applied across the disk
  HALO_FRAC: number;   // fraction of points in the spherical halo (0..1)
}

export interface GeometryData {
  positions: Float32Array; // length COUNT * 3
  colors: Float32Array;    // length COUNT * 3, normalized 0..1 RGB
  count: number;
}

export const DEFAULT_GALAXY: GalaxyParams = {
  COUNT: 20000,
  ARM_COUNT: 2,
  SPREAD: 0.9,
  RADIUS: 60,
  TILT: 0.08,
  HALO_FRAC: 0.12,
};

// Standalone HSL->RGB (h,s,l in 0..1) -> [r,g,b] in 0..1.
// Replaces THREE.Color().setHSL so galaxyData stays engine-neutral.
function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  if (s === 0) return [l, l, l];
  const hue2rgb = (p: number, q: number, t: number) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  return [
    hue2rgb(p, q, h + 1 / 3),
    hue2rgb(p, q, h),
    hue2rgb(p, q, h - 1 / 3),
  ];
}

const clamp01 = (x: number) => (x < 0 ? 0 : x > 1 ? 1 : x);

export function buildGalaxyData(params: GalaxyParams): GeometryData {
  const { COUNT, ARM_COUNT, SPREAD, RADIUS, TILT, HALO_FRAC } = params;

  const positions = new Float32Array(COUNT * 3);
  const colors = new Float32Array(COUNT * 3);

  for (let i = 0; i < COUNT; i++) {
    // Deterministic pseudo-random seeds (same scheme as your original).
    const seed1 = ((i * 127 + 31) % COUNT) / COUNT;
    const seed2 = ((i * 7919 + 97) % COUNT) / COUNT;
    const seed3 = ((i * 1009 + 53) % COUNT) / COUNT;

    const haloMask = seed3 < HALO_FRAC ? 1.0 : 0.0;
    const diskMask = 1.0 - haloMask;

    // Disk — exponential radial distribution
    const rawR = -Math.log(1.0 - seed1 * 0.9999);
    const diskR = rawR * (RADIUS / 4.5);

    // Spiral arm placement
    const arm = Math.floor(seed2 * ARM_COUNT);
    const armOffset = (arm / ARM_COUNT) * Math.PI * 2.0;
    const spiralTwist = diskR * 0.55;
    const scatter = (seed2 * 2.0 - 1.0) * SPREAD * (diskR / RADIUS) * 8.0;
    const armAngle = armOffset + spiralTwist + scatter;

    const diskX = Math.cos(armAngle) * diskR;
    const diskZ = Math.sin(armAngle) * diskR;
    const diskY = (seed1 - 0.5) * 1.8 * (diskR / RADIUS + 0.05);

    // Halo — spherical shell
    const hTheta = seed1 * Math.PI * 2.0;
    const hPhi = Math.acos(2.0 * seed2 - 1.0);
    const hR = RADIUS * (0.4 + seed3 * 1.4);

    const haloX = Math.sin(hPhi) * Math.cos(hTheta) * hR;
    const haloY = Math.cos(hPhi) * hR;
    const haloZ = Math.sin(hPhi) * Math.sin(hTheta) * hR;

    const finalX = diskX * diskMask + haloX * haloMask;
    const finalY = diskY * diskMask + haloY * haloMask + finalX * TILT;
    const finalZ = diskZ * diskMask + haloZ * haloMask;

    positions[i * 3] = finalX;
    positions[i * 3 + 1] = finalY;
    positions[i * 3 + 2] = finalZ;

    // Color — stellar temperature by radius / zone
    const normR = diskR / RADIUS;
    const coreGlow = Math.exp(-normR * 3.5);

    const diskHue = 0.58 - normR * 0.48 + (seed1 - 0.5) * 0.04;
    const diskSat = 0.55 + coreGlow * 0.35;
    const diskLit = 0.35 + coreGlow * 0.5 + seed1 * 0.12;

    const haloHue = 0.07 + seed2 * 0.06;
    const haloLit = 0.22 + seed1 * 0.2;

    const finalHue = diskHue * diskMask + haloHue * haloMask;
    const finalSat = diskSat * diskMask + 0.5 * haloMask;
    const finalLit = diskLit * diskMask + haloLit * haloMask;

    const [r, g, b] = hslToRgb(
      clamp01(finalHue),
      clamp01(finalSat),
      clamp01(finalLit),
    );
    colors[i * 3] = r;
    colors[i * 3 + 1] = g;
    colors[i * 3 + 2] = b;
  }

  return { positions, colors, count: COUNT };
}
