// src/App.tsx
//
// The foundation: a single <Canvas> (default WebGL renderer — rock-solid;
// switch to WebGPU later as a deliberate step), OrbitControls from drei, and
// the galaxy.
//
// STAGED VERIFICATION (mirrors the old smoke test, on the path that should pass):
//   - Set SHOW_TEST_MESH = true first. You should see a blue box you can orbit
//     around with the mouse. That proves Canvas + camera + controls + render
//     loop all work.
//   - Then set SHOW_TEST_MESH = false. You should see the spiral galaxy.
//   - If the box works but the galaxy doesn't, the issue is in the galaxy
//     adapter, not the foundation — a much narrower thing to debug.

import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import Galaxy from './generators/Galaxy';

const SHOW_TEST_MESH = false; // flip to true for the foundation smoke test

function TestMesh() {
  return (
    <mesh>
      <boxGeometry args={[2, 2, 2]} />
      <meshStandardMaterial color="#5ab0ff" />
    </mesh>
  );
}

export default function App() {
  return (
    <div style={{ width: '100vw', height: '100vh', background: '#05060a' }}>
      <Canvas
        camera={{ position: [0, 30, 90], fov: 60, near: 0.1, far: 2000 }}
        gl={{ antialias: true }}
      >
        {/* Lights only matter for the standard-material test box; the galaxy
            uses vertex colors + additive blending and is unlit. */}
        <ambientLight intensity={0.6} />
        <pointLight position={[50, 50, 50]} intensity={1.2} />

        {SHOW_TEST_MESH ? <TestMesh /> : <Galaxy />}

        <OrbitControls
          enableDamping
          dampingFactor={0.05}
          minDistance={10}
          maxDistance={500}
        />
      </Canvas>
    </div>
  );
}
