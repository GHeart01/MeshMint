// src/generators/Galaxy.tsx
//
// The thin Three/R3F ADAPTER. All it does is take the engine-neutral
// { positions, colors } from buildGalaxyData and feed them into a <points>.
// This is the only file that knows about Three; the math lives in galaxyData.ts.

import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import {
  buildGalaxyData,
  DEFAULT_GALAXY,
  type GalaxyParams,
} from './galaxyData';

interface GalaxyProps {
  params?: GalaxyParams;
  rotationSpeed?: number;
  pointSize?: number;
}

// Builds the soft circular sprite your original used (radial-gradient dot),
// so points read as glowing stars rather than hard squares.
function makeCircleTexture(): THREE.Texture {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.4, 'rgba(255,255,255,0.8)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(32, 32, 32, 0, Math.PI * 2);
  ctx.fill();
  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

export default function Galaxy({
  params = DEFAULT_GALAXY,
  rotationSpeed = 0.18,
  pointSize = 0.15,
}: GalaxyProps) {
  const pointsRef = useRef<THREE.Points>(null);

  // Recompute geometry only when params change (not every render/frame).
  const { geometry, texture } = useMemo(() => {
    const { positions, colors } = buildGalaxyData(params);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    return { geometry: geo, texture: makeCircleTexture() };
  }, [params]);

  // Differential rotation approximated by spinning the whole object (as before).
  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y =
        state.clock.elapsedTime * rotationSpeed * 0.15;
    }
  });

  return (
    <points ref={pointsRef} geometry={geometry}>
      <pointsMaterial
        size={pointSize}
        sizeAttenuation
        vertexColors
        map={texture}
        depthWrite={false}
        transparent
        alphaTest={0.001}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}
